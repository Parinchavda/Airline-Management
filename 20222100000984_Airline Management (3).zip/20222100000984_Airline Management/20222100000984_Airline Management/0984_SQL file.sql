use admin;
create table cancel ( 
ticketid varchar(20),
sorce varchar(20),
destination varchar(20),
clas varchar(20),
price varchar(20),
flightcode varchar(20),
flightname varchar(20),
journeydate varchar(20),
journeytime varchar(20),
username varchar(20),
reason varchar(20),
statuss varchar(20)
);
create table addpas ( 
username varchar(20),
age int(20),
address varchar (20),
gmail varchar(20),
gender varchar (20),
dob date,
phone bigint(10),
nationnality varchar(20),
passportno varchar(20)
);
create table ademp (
username varchar(20),
employname varchar(20),
password varchar(20),
phone int(10)
);
create table bookfli(
ticketid varchar(20),
sorce varchar(20),
destination varchar(20),
class varchar(20),
price varchar(20),
flightcode varchar(20),
flightname varchar(20),
journeytime varchar(20),
journrydate varchar(20),
username varchar(20),
status varchar(20)
);
create table faddflight(
flightcode varchar(20),
flightname varchar(20),
sourcee varchar(20),
destination varchar(20),
classname varchar(20),
cpacity int(20),
price int(20)
);
