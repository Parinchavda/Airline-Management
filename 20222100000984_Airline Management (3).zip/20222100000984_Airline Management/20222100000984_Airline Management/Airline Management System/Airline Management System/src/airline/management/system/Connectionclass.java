package airline.management.system;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Connectionclass {
    
    Connection con;
    Statement  smt;
        
      public Connectionclass()
      {
          try{
              Class.forName("com.mysql.cj.jdbc.Driver");
              
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/admin", "root", "Example@2022#");
            smt = con.createStatement();
          }catch(Exception e)
          {
              System.out.println(e.getMessage());
          }
      }
     public static void main(String[] args) {
     Connectionclass obj = new Connectionclass();
      }
}
